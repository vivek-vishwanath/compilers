package backend.interpreter.mips.operand;

public abstract class MIPSOperand {

}
